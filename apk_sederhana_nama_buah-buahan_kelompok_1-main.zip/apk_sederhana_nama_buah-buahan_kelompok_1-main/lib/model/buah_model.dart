class BuahModel {
  String? namaBuah,gambarBuah,detailBuah;

BuahModel({this.namaBuah,this.gambarBuah,this.detailBuah});


}